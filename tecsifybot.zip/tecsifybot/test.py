import datetime
import time  
# datetime(year, month, day, hour, minute, second)
c = datetime.datetime.now()

time.sleep(3)
d = datetime.datetime.now()

f = d-c
print('Difference: ',f)
  
minutes = divmod(f.total_seconds(), 60) 
print('Total difference in minutes: ', minutes[0], 'minutes',
                                 minutes[1], 'seconds')