import requests
from bs4 import BeautifulSoup as soup


class Empleo:
    def __init__(self, titulo, descripcion, ciudad, url):
        self.titulo = titulo
        self.descripcion = descripcion
        self.ciudad = ciudad
        self.url = url

        
def get_linkedin_empleos(profession, city):
        try:
            req = requests.get(
                f'https://www.linkedin.com/jobs/search?keywords={profession}&location={city}&geoId=&trk=homepage-jobseeker_jobs-search-bar_search-submit&redirect=false&position=1&pageNum=0'
            )
            req.raise_for_status()

            # create Soup
            page_soup = soup(req.text, 'html.parser')
            return extract_job_links(page_soup)
        except requests.HTTPError as err:
            print(f'Something went wrong! {err}')


def extract_job_links(cursor):
    total_jobs = []

    for res_card in cursor.find_all('a', {"class": "base-search-card--link"}): 
    #for links in res_card.findAll('div', {'class': 'base-search-card__info'}):
        titulo = res_card.find("div", { "class" : "base-search-card__info" }).find("h3",{"class": "base-search-card__title"}, recursive=False)
        descripcion = res_card.find("div", { "class" : "base-search-card__info" }).find('h4', {"class": "base-search-card__subtitle"}, recursive=False)
        loc = res_card.find("div", { "class" : "base-search-card__info" }).find("div", {"class":'base-search-card__metadata'}).find('span', {"class": "job-search-card__location"}, recursive=False)
        
        titulo = titulo.text.replace('\n','').replace("                ","")[4:]
        descripcion = descripcion.text.replace('\n','').replace("                  ","")[6:]
        loc = loc.text.replace('\n','').replace("          ","")[2:]

        url = res_card['href']

        x = Empleo(titulo, descripcion, loc, url) 
        total_jobs.append(x)
    return total_jobs

