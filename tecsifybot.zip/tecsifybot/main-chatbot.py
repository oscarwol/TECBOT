"""
- TecsifyBOT: Sistema de procesamiento del lenguaje humano de Tecsify Latinoamerica
- Version: 1.0
- Created for: Tecsify (www.Tecsify.com) (contacto@tecsify.com)
- License: Tecsify Private Software
- Author: Oscar E. Morales (oscarmoralesgt.com)

- Rights reserved, This program and code is issued for the purposes that the interested party deems appropriate.
"""

# Importamos las librerias y paquetes necesarios
from datetime import datetime 
from re import I, fullmatch, sub
import smtplib
from telegram import (
    Update,
    ReplyKeyboardRemove,
    ReplyKeyboardMarkup,
    ParseMode,
)
from telegram.ext import (
    Updater,
    CommandHandler,
    CallbackContext,
    MessageHandler,
    Filters,
)
import requests
from linkedin import get_linkedin_empleos
import pyshorteners

import wikipedia 
wikipedia.set_lang("es")



if __name__ == "__main__":
    updater = Updater("5591261069:AAECMoYpj43GSYcUZPYRUDxplaoBU5mt-bs")
    reply_keyboard = [["codigos", "infografias", "articulos"], ["contacto", "donar", "empleos"]]
    type_tiny = pyshorteners.Shortener()

    markup = ReplyKeyboardMarkup(reply_keyboard, one_time_keyboard=True)

    #Funcion para saber si el usuario tiene una sesión activa con el bot
    def user_has_data(update, context):
        return bool(context.user_data)

    
    # Funcion de Inicio (Disparador / Trigger)
    def Inicio_Bot(update,context):
        context.user_data["datos_usuario"] = {"Correo": None, "Correo_Asunto": None, "Correo_Body": None, "Empleo-Pais": None, "Empleo-Tipo": None, "Empleo-Tiempo": None, "Wiki-Tiempo": None}
        start(update,context)

    def start(update: Update, context: CallbackContext) -> None:
        data = context.user_data["datos_usuario"] 
        data["Correo"] = None
        data["Correo_Asunto"] = None
        data["Correo_Body"] = None
        data["Empleo-Pais"] = None
        data["Empleo-Tipo"] = None
        data["Wiki"] = None
        context.user_data["estado"] = "Menu:Inicial"
        welcomeMessage(update,context)
        menuInicial(update, context)
        seleccion_por_numero(update, context)

    def welcomeMessage(update, context):
        nombre_de_usuario = update.message.from_user.first_name
        update.message.reply_text(
            "¡Hola *{}*! Bienvenido a Tecsify BOT, un sistema de comunicación automatizada de *Tecsify\n¿Cómo podemos ayudarte hoy?*".format(
                nombre_de_usuario),
                parse_mode=ParseMode.MARKDOWN,
        )


    # Funcion que nos permite seleccion por numero en los diferentes menus
    def seleccion_por_numero(update, context):
        echo_handler = MessageHandler(Filters.text & (~Filters.command), echo)
        updater.dispatcher.add_handler(echo_handler)

    """
    Codigos interactivos & Infografias
    """
    def codigos_infografias(update,context, tipo):
        if tipo == "codigo":
            plural = "Códigos interactivos"
            texto_inicio = "Estos son los 5 Códigos interactivos más recientes públicados en nuestro blog:"
            url_blog = "https://Tecsify.com/blog/codigos"
            emoji = "💻"
        elif tipo == "infografia":
            plural = "Infografías"
            texto_inicio = "Estas son las 5 Infografías más recientes públicadas en nuestro blog:"
            url_blog = "https://Tecsify.com/blog/infografias"
            emoji = "📑"
        elif tipo == "articulo":
            plural = "Articulos"
            texto_inicio = "Estas son las 5 Entradas/Articulos más recientes públicadas en nuestro blog:"
            url_blog = "https://Tecsify.com/blog/"
            tipo = "posts"
            emoji = "🟢"
        else:
            return
        endpoint = "https://tecsify.com/blog/wp-json/wp/v2/%s" % tipo
        response = requests.get(endpoint)
        respuesta = response.json()
        if response.status_code == 200 and len(respuesta) > 0:
            update.message.reply_text(
                texto_inicio)
            for object in respuesta[:5]:
                titulo = object["title"]['rendered']
                descripcion = object["yoast_head_json"]['description']
                url = object["link"]
                

                update.message.reply_text(
                    "{} *{}*:\n\n{}\n\n👉 {}".format(emoji, titulo, descripcion, url),parse_mode=ParseMode.MARKDOWN,
                    disable_web_page_preview=True
                )
            update.message.reply_text(
                "📌 ¡Puedes ver el listado completo en el portal de *{}* de nuestro blog!\n\n👉 {}".format(plural, url_blog),parse_mode=ParseMode.MARKDOWN,
                    disable_web_page_preview=True
                )
        else:
            update.message.reply_text((
                "No hay {} en este momento ¡Vuelve más tarde!".format(plural)
                ))
        VolverAlMenu(update, context)

    """
    Contacto con Tecsify
    """
    def contacto(update,context):
        context.user_data["estado"] = "Pregunta:Correo_Asunto"
        verificar_datos_correo(update,context)

    
    """
    Donar a Tecsify
    """
    def donar(update,context):
        nombre_de_usuario = update.message.from_user.first_name
        url = "https://www.buymeacoffee.com/tecsify"
        update.message.reply_text(
            "❤️ ¡Hey *{}*! ❤️, ¡Gracias por compartir nuestra misión de una *latinoamérica con educación, tecnología e innovación al alcance de todos*!\n\nTu apoyo es muy importante, puedes realizar un pequeño donativo mediante la plataforma 'Buy Me a Coffee' en el siguiente enlace: \n\n👉 {}\n\n*¡Gracias por ser parte de Tecsify!*".format(
                nombre_de_usuario, url),
                parse_mode=ParseMode.MARKDOWN,
        )
        VolverAlMenu(update, context)

    def diferenciar_tiemmpos(tiempo):
        tiempo_actual = datetime.now()
        diferencia = tiempo_actual - tiempo 
        minutes = divmod(diferencia.total_seconds(), 60) 
        return (minutes[0], minutes[1])



    def wiki(update,context):
        tiempo  = context.user_data["datos_usuario"]["Wiki-Tiempo"]
        if tiempo == None: 
            context.user_data["datos_usuario"]["Wiki-Tiempo"] = datetime.now()
            context.user_data["estado"] = "Pregunta:Wiki"
            datos_wiki(update,context)
        else:
            diferencias = diferenciar_tiemmpos(tiempo)
            if diferencias[0] < 1:
                update.message.reply_text("⏰ Por favor, Debes esperar 1 minuto entre cada consulta  para no saturar los servidores")
                update.message.reply_text("Han pasado {} segundos desde tu ultima consulta".format(int(diferencias[1])))
            else:
                context.user_data["datos_usuario"]["Wiki-Tiempo"] = None
                wiki(update,context)


    def datos_wiki(update,context):
        estado = context.user_data["estado"]
        if estado == "Pregunta:Wiki":
            update.message.reply_text("¡Bienvenido al módulo de enciclopedico de Tecsify! aquí encontrarás la información sobre todo aquello que quieres saber 👇:")
            update.message.reply_text("📖 Por favor, Ingresa específicamente los términos de búsqueda \n(ejemplo 'Nikola Tesla' o 'Javascript' o 'Célula Vegetal'")
            context.user_data["estado"] = "Respuesta:Wiki"
            seleccion_por_numero(update,context)
        elif estado == "Done":
            context.user_data["estado"] = "Menu:Inicial"
            update.message.reply_text("Encontramos esto acerca de " + context.user_data["datos_usuario"]["Wiki"] +":")
            buscar = context.user_data["datos_usuario"]["Wiki"]
            try:
                summary = wikipedia.summary(buscar , sentences = 3, chars = 0 , auto_suggest = True , redirect = True ) 
                pattern = r'\[.*?\]'
                summary = sub(pattern, '', summary)
            except:
                summary = "No se encontraron resultados para esta búsqueda :("
            update.message.reply_text(summary, parse_mode=ParseMode.HTML)

            VolverAlMenu(update, context)







    def empleos(update,context):
        tiempo  = context.user_data["datos_usuario"]["Empleo-Tiempo"]
        if tiempo == None: 
            context.user_data["datos_usuario"]["Empleo-Tiempo"] = datetime.now()
            context.user_data["estado"] = "Pregunta:Empleo-Pais"
            datos_empleos(update,context)
        else:
            diferencias = diferenciar_tiemmpos(tiempo)
            if diferencias[0] < 2:
                update.message.reply_text("⏰ Por favor, Debes esperar 2 minutos entre cada consulta de empleos para no saturar los servidores")
                update.message.reply_text("Han pasado {} min con {} segundos desde tu ultima consulta".format(int(diferencias[0]), int(diferencias[1])))
            else:
                context.user_data["datos_usuario"]["Empleo-Tiempo"] = None
                empleos(update,context)

    def datos_empleos(update,context):
        estado = context.user_data["estado"]
        if estado == "Pregunta:Empleo-Pais":
            update.message.reply_text("¡Bienvenido al módulo de empleos de Tecsify! aquí encontrarás los empleos más recientes de LinkedIn en unos simples pasos 👇:")
            update.message.reply_text("🌎 Por favor, Ingresa de que país eres:")
            context.user_data["estado"] = "Respuesta:Empleo-Pais"
            seleccion_por_numero(update,context)
        elif estado == "Pregunta:Empleo-Tipo":
            update.message.reply_text("¡Bien hecho!")
            update.message.reply_text("👤 Ahora, escribe el tipo de trabajo o la tecnología con la que te gustaría trabajar (Ejemplo: 'Python' o 'Abogado")
            context.user_data["estado"] = "Respuesta:Empleo-Tipo"
            seleccion_por_numero(update,context) 
        elif estado == "Done":
            context.user_data["estado"] = "Menu:Inicial"
            update.message.reply_text("¡Hemos encontrado estos empleos para ti!:")
            ciudad = context.user_data["datos_usuario"]["Empleo-Pais"]
            tipo = context.user_data["datos_usuario"]["Empleo-Tipo"]
            buscar_empleos(update,context, ciudad, tipo)
            VolverAlMenu(update, context)

    def buscar_empleos(update,context,ciudad,tipo):
        empleos = get_linkedin_empleos(tipo,ciudad)
        for empleo in empleos:
            short_url = type_tiny.tinyurl.short(empleo.url)
            texto = "📌 *{}*\n*🏢 Empresa*: {}\n📍 *Localización*: {}\n\n🌐 URL para aplicar: {}\n\n".format(empleo.titulo, empleo.descripcion, empleo.ciudad, short_url)
            update.message.reply_text(texto,parse_mode=ParseMode.MARKDOWN)
        update.message.reply_text("❗ Estos empleos fueron obtenidos desde LinkedIn no publicados y/o relacionados con Tecsify ",parse_mode=ParseMode.MARKDOWN)

    """
    Menus y Opciones disponibles dentro del chat
    """

    def menuInicial(update, context):
        update.message.reply_text(
            "Escribe 1️⃣ o *codigos* para ver el listado de los *Códigos interactivos* más recientes de nuestro blog",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=markup,
        )
        update.message.reply_text(
            "Escribe 2️⃣ o *infografias* para ver el listado de las *Infografías* más recientes de nuestro blog",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=markup,
        )
        update.message.reply_text(
            "Escribe 3️⃣ o *articulos* para ver el listado de los *Articulos/Entradas* más recientes de nuestro blog",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=markup,
        )
        update.message.reply_text(
            "Escribe 4️⃣ o *contacto* Para ponerte en contacto directo con el equipo de Tecsify",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=markup,
        )
        update.message.reply_text(
            "Escribe 5️⃣ o *donar* para convertirte en patrocinador del Empoderamiento Tecnológico en Latinoamérica",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=markup,
        )
        update.message.reply_text(
            "Escribe 6️⃣ o *empleos* para buscar un empleo mediante LinkedIn",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=markup,
        )
        update.message.reply_text(
            "Escribe 7️⃣ para buscar en nuestra enciclopédia (Beta)",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=markup,
        )        

    def VolverAlMenu(update, context):
        if context.user_data["estado"] == "Menu:Inicial":
            update.message.reply_text(
                "Escribe 0️⃣ para mostar el menu nuevamente, o elige una de las opciones anteriores"
            )
        seleccion_por_numero(update, context)


    """
    Seccion de Promociones y verificación de códigos Promocionaels:

    """


    def check_valid_email (email):
        regex = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
 
        if(fullmatch(regex, email)):
            return True
        return False

    def check_valid_email_data(asunto, total_char):
        if len(asunto) >= total_char:
            return True
        return False

    # Consumo del Endpoint de promociones y match de datos
    def datosIngresados(update, context):
        datos_usuario = context.user_data["datos_usuario"]
        cui = str(datos_usuario["CUI"]).upper()
        pais = datos_usuario["Pais"]

        correo = str(datos_usuario["correo"]).upper()
        if pais == "Nicaragua":
            endpoint = "https://apiswolgroup.com/chatbot/usuarios/nicaragua/%s" % cui
        else:
            endpoint = "https://apiswolgroup.com/chatbot/usuarios/panama/%s" % cui
        response = requests.get(endpoint)
        if response.status_code == 200:
            respuesta = response.json()
            this_correo = str(respuesta["email"]).upper()
            this_cui = str(respuesta["cui"]).upper()
            this_nombre = respuesta["nombre"]
            this_codigo = respuesta["codigo"]
            if str(correo) == str(this_correo):

                update.message.reply_text(
                    "Hola %s Hemos validado los siguientes datos:" % this_nombre
                )
                update.message.reply_text(
                    "Nombre: {}\nCédula: {}\nCorreo Electronico: {}\nCódigo: {}\nPais: {}".format(
                        this_nombre, this_cui, this_correo, this_codigo, pais
                    )
                )
                update.message.reply_text(
                    "Se ha enviado un correo electrónico a %s con tu código promocional:"
                    % this_correo
                )

                """
                Envio de Email:
                """
                correo_user = "ataraxiaguatemala@gmail.com"
                password = "Ernesto1?"
                subject = "Cerveza Tona: Tu código promocional"

                body = "\nHola: {}! Estos son tus datos registrados en nuestro sistema:\nCédula: {}\nCorreo Electrónico: {}\nCódigo: {}\nPaís: {}".format(
                    this_nombre, this_cui, this_correo, this_codigo, pais
                )
                sent_from = correo_user
                to = [this_correo]

                email_text = "Subject: {}\n\n{}".format(subject, body)
                try:
                    smtp_server = smtplib.SMTP_SSL("smtp.gmail.com", 465)
                    smtp_server.ehlo()
                    smtp_server.login(correo_user, password)
                    smtp_server.sendmail(sent_from, to, email_text)
                    smtp_server.close()
                    print("Email sent successfully!")
                except Exception as ex:
                    print("Something went wrong….", ex)

            else:
                update.message.reply_text(
                    "La Cédula {} y/o correo {} no estan asociados".format(cui, correo)
                )
        else:
            update.message.reply_text(
                "La Cédula %s no esta registrada en la base de datos" % cui
            )
        datos_usuario["Correo"] = None
        datos_usuario["Correo_Asunto"] = None
        datos_usuario["Correo_Body"] = None

        VolverAlMenu(update, context)



    def verificar_datos_correo(update: Update, context: CallbackContext) -> None:
        estado = context.user_data["estado"]
        if estado == "Pregunta:Correo_Asunto":
            update.message.reply_text("¡Bienvenido al módulo de contácto! aquí podrás ponerte en contacto directo con el equipo de Tecsify en unos simples pasos 👇:")
            update.message.reply_text("✏️ Por favor, Ingresa el asunto del correo (Titulo del correo, 10 caracteres minímo) :")
            context.user_data["estado"] = "Respuesta:Correo_Asunto"
            seleccion_por_numero(update,context)
        elif estado == "Pregunta:Correo_Body":

            if check_valid_email_data(context.user_data["datos_usuario"]["Correo_Asunto"], 10):
                context.user_data["estado"] = "Pregunta:Correo_Body"
                update.message.reply_text("¡Bien hecho!")
                update.message.reply_text("📝 Ahora, escribe tu nombre acompañado un pequeño texto detallando la razón de tu contacto 😊: (50 caracteres minímo) ")
                context.user_data["estado"] = "Respuesta:Correo_Body"
                seleccion_por_numero(update,context) 
            else:
                context.user_data["estado"] = "Respuesta:Correo_Asunto_Invalido"
                update.message.reply_text("El asunto debe tener al menos 15 caracteres 😟")
                update.message.reply_text("Escribe 1️⃣ para escribir nuevamente el asunto, o cualquier otro número para regresar al menú.")
                seleccion_por_numero(update,context)

   
        
        elif estado == "Pregunta:Correo":
            if check_valid_email_data(context.user_data["datos_usuario"]["Correo_Body"], 50):
                context.user_data["estado"] = "Pregunta:Correo"
                update.message.reply_text("¡Inspirador 😍!")
                update.message.reply_text("📩 Ahora, escribe tu correo electrónico para que podamos ponernos en contacto:")
                context.user_data["estado"] = "Respuesta:Correo"
                seleccion_por_numero(update,context)
            else:
                context.user_data["estado"] = "Respuesta:Correo_Body_Invalido"
                update.message.reply_text("El motivo debe tener al menos 50 caracteres 😟")
                update.message.reply_text("Escribe 1️⃣ para escribir nuevamente el correo, o cualquier otro número para regresar al menú.")
                seleccion_por_numero(update,context)


        elif estado == "Done":
            if check_valid_email(context.user_data["datos_usuario"]["Correo"]):
                context.user_data["estado"] = "Menu:Inicial"
                update.message.reply_text("¡Hemos recibido tu solicitud de contacto 😉! Te llegará una copia de esta misma al buzón del correo ingresado")
                update.message.reply_text(context.user_data["datos_usuario"]["Correo_Asunto"] +"\n"+ context.user_data["datos_usuario"]["Correo_Body"]+"\n"+context.user_data["datos_usuario"]["Correo"])
                VolverAlMenu(update, context)
            else:
                context.user_data["estado"] = "Respuesta:Correo_Invalido"
                update.message.reply_text("No ingresaste un correo válido 😟")
                update.message.reply_text("Escribe 1️⃣ para escribir nuevamente el correo, o cualquier otro número para regresar al menú.")
                seleccion_por_numero(update,context)

            



    # Funcion central
    def echo(update, context):
        if user_has_data(update,context):
            estado = context.user_data["estado"]
            datos_usuario = context.user_data["datos_usuario"]
            opcion = update.message.text
            if estado == "Respuesta:Correo_Asunto":
                datos_usuario["Correo_Asunto"] = update.message.text
                context.user_data["estado"] = "Pregunta:Correo_Body"
                verificar_datos_correo(update,context)


            elif estado == "Respuesta:Correo_Body":
                    datos_usuario["Correo_Body"] = update.message.text
                    context.user_data["estado"] = "Pregunta:Correo"
                    verificar_datos_correo(update,context)

            elif estado == "Respuesta:Correo":
                    datos_usuario["Correo"] = update.message.text
                    context.user_data["estado"] = "Done"
                    verificar_datos_correo(update,context)
            
            elif estado == "Respuesta:Correo_Asunto_Invalido":
                if int(opcion) == 1:
                    context.user_data["estado"] = "Pregunta:Correo_Asunto"
                    verificar_datos_correo(update,context)
                else:
                    start(update, context)
            
            elif estado == "Respuesta:Correo_Body_Invalido":
                if int(opcion) == 1:
                    context.user_data["estado"] = "Pregunta:Correo_Body"
                    verificar_datos_correo(update,context)
                else:
                    start(update, context)

            elif estado == "Respuesta:Correo_Invalido":
                if int(opcion) == 1:
                    context.user_data["estado"] = "Pregunta:Correo"
                    verificar_datos_correo(update,context)
                else:
                    start(update, context)

            ##Parte de Linkedin
            
            elif estado == "Respuesta:Empleo-Pais":
                datos_usuario["Empleo-Pais"] = update.message.text
                context.user_data["estado"] = "Pregunta:Empleo-Tipo"
                datos_empleos(update,context)
           
            elif estado == "Respuesta:Empleo-Tipo":
                datos_usuario["Empleo-Tipo"] = update.message.text
                context.user_data["estado"] = "Done"
                datos_empleos(update,context)
                
            elif estado == "Respuesta:Wiki":
                datos_usuario["Wiki"] = str(update.message.text).capitalize()
                context.user_data["estado"] = "Done"
                datos_wiki(update,context)
            #####

            elif estado == "Menu:Inicial":
                if True:
                    if opcion == "codigos":
                        codigos_infografias(update, context, 'codigo')
                    elif opcion == "infografias":
                        codigos_infografias(update, context, 'infografia')
                    elif opcion == "articulos":
                        codigos_infografias(update, context, 'articulo')
                    elif opcion == "contacto":
                        contacto(update, context)
                    elif opcion == "donar":
                        donar(update, context)       
                    elif opcion == "empleos":
                        empleos(update, context)              
                    else:
                        opcion = int(opcion)
                        if opcion < 0 or opcion > 7:
                            update.message.reply_text(
                                text="El Numero ingresado "
                                + update.message.text
                                + " No forma parte del menu, elija otra vez.",
                            )
                            start(update, context)
                        else:
                            if opcion == 0:
                                start(update, context)
                            elif opcion == 1:
                                codigos_infografias(update, context, 'codigo')
                            elif opcion == 2:
                                codigos_infografias(update, context, 'infografia')
                            elif opcion == 3:
                                codigos_infografias(update, context, 'articulo')
                            elif opcion == 4:
                                contacto(update,context)
                            elif opcion == 5:
                                donar(update,context)
                            elif opcion == 6:
                                empleos(update,context)
                            elif opcion == 7:
                                wiki(update,context)
                else:#exceptel:
                    update.message.reply_text("Opcion no valida, elija otra vez.")
                    start(update, context)
        else:
            Inicio_Bot(update, context)

    # Inicio y disparador del bot

    echo_handler = MessageHandler(Filters.text & (~Filters.command), echo)
    updater.dispatcher.add_handler(echo_handler)
    updater.dispatcher.add_handler(CommandHandler("start", Inicio_Bot))

    updater.start_polling()
    updater.idle()
